package desafio2.Entidades.Services;

import desafio2.Entidades.Alquiler;
import desafio2.Entidades.Pelicula;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AlquilerService {
    
    private List<Alquiler> alquileres;

    public AlquilerService() {
        this.alquileres = new ArrayList<>();
    }

    public void crearAlquiler(Pelicula pelicula, Date fechaInicio, Date fechaFin, double precio) {
        Alquiler alquiler = new Alquiler(pelicula, fechaInicio, fechaFin, precio);
        alquileres.add(alquiler);
    }

    public void listarAlquileres() {
        System.out.println("Alquileres realizados:");
        for (Alquiler alquiler : alquileres) {
            System.out.println("Película: " + alquiler.getPelicula().getTitulo());
            System.out.println("Fecha de inicio: " + alquiler.getFechaInicio());
            System.out.println("Fecha de fin: " + alquiler.getFechaFin());
            System.out.println("Precio: $" + alquiler.getPrecio());
            System.out.println("----------------------");
        }
    }

    public Alquiler buscarAlquilerPorFecha(Date fecha) {
        for (Alquiler alquiler : alquileres) {
            if (alquiler.getFechaInicio().equals(fecha) || alquiler.getFechaFin().equals(fecha)) {
                return alquiler;
            }
        }
        return null;
    }

    public double calcularIngresoTotal() {
        double ingresoTotal = 0;
        for (Alquiler alquiler : alquileres) {
            ingresoTotal += alquiler.getPrecio();
        }
        return ingresoTotal;
    }
}