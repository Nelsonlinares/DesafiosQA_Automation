package desafio2.Entidades.Services;

import desafio2.Entidades.Pelicula;
import java.util.ArrayList;
import java.util.List;

public class PeliculaService {

    private List<Pelicula> peliculas;

    public PeliculaService() {
        this.peliculas = new ArrayList<>();
    }

    public void crearPelicula(String titulo, String genero, int anio, int duracion) {
        Pelicula pelicula = new Pelicula(titulo, genero, anio, duracion);
        peliculas.add(pelicula);
    }

    public void listarPeliculasDisponibles() {
        System.out.println("Películas disponibles:");
        for (Pelicula pelicula : peliculas) {
            System.out.println("Título: " + pelicula.getTitulo());
            System.out.println("Género: " + pelicula.getGenero());
            System.out.println("Año: " + pelicula.getAnio());
            System.out.println("Duración: " + pelicula.getDuracion() + " minutos");
            System.out.println("----------------------");
        }
    }

    public Pelicula buscarPeliculaPorTitulo(String titulo) {
        for (Pelicula pelicula : peliculas) {
            if (pelicula.getTitulo().equalsIgnoreCase(titulo)) {
                return pelicula;
            }
        }
        return null;
    }

    public Pelicula buscarPeliculaPorGenero(String genero) {
        for (Pelicula pelicula : peliculas) {
            if (pelicula.getGenero().equalsIgnoreCase(genero)) {
                return pelicula;
            }
        }
        return null;
    }
}