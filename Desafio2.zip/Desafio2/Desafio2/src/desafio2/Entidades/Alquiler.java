package desafio2.Entidades;

import java.util.Date;

/**
 *
 * @author administrador
 */
public class Alquiler {
    
    private Pelicula pelicula;
    private Date fechaInicio;
    private Date fechaFin;
    private double precio;

    public Alquiler(Pelicula pelicula, Date fechaInicio, Date fechaFin, double precio) {
        this.pelicula = pelicula;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.precio = precio;
    }

    public Pelicula getPelicula() {
        return pelicula;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public double getPrecio() {
        return precio;
    }
}