package desafio2;

import desafio2.Entidades.Services.AlquilerService;
import desafio2.Entidades.Pelicula;
import desafio2.Entidades.Services.PeliculaService;
import java.util.Date;
import java.util.Scanner;

public class Desafio2 {

    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
        PeliculaService peliculaService = new PeliculaService();
        AlquilerService alquilerService = new AlquilerService();

        // Crear películas de ejemplo
        peliculaService.crearPelicula("Pelicula 1", "Drama", 2020, 120);
        peliculaService.crearPelicula("Pelicula 2", "Comedia", 2018, 90);
        peliculaService.crearPelicula("Pelicula 3", "Acción", 2019, 110);
        peliculaService.crearPelicula("Pelicula 4", "Aventura", 2021, 130);
        peliculaService.crearPelicula("Pelicula 5", "Thriller", 2017, 100);

        // Realizar alquileres de ejemplo
        alquilerService.crearAlquiler(peliculaService.buscarPeliculaPorTitulo("Pelicula 1"),
                new Date(2023, 6, 1), new Date(2023, 6, 4), 30);
        alquilerService.crearAlquiler(peliculaService.buscarPeliculaPorTitulo("Pelicula 2"),
                new Date(2023, 6, 2), new Date(2023, 6, 5), 30);
        alquilerService.crearAlquiler(peliculaService.buscarPeliculaPorTitulo("Pelicula 3"),
                new Date(2023, 6, 3), new Date(2023, 6, 6), 30);

        int opcion;
        do {
            System.out.println("Menú:");
            System.out.println("1. Cargar una película");
            System.out.println("2. Listar todas las películas disponibles");
            System.out.println("3. Crear un alquiler");
            System.out.println("4. Listar todos los alquileres");
            System.out.println("5. Buscar una película por título");
            System.out.println("6. Buscar una película por género");
            System.out.println("7. Buscar un alquiler por fecha");
            System.out.println("8. Calcular el ingreso total del servicio");
            System.out.println("9. Salir");
            System.out.print("Ingrese una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el título de la película: ");
                    String titulo = scanner.next();
                    System.out.print("Ingrese el género de la película: ");
                    String genero = scanner.next();
                    System.out.print("Ingrese el año de la película: ");
                    int anio = scanner.nextInt();
                    System.out.print("Ingrese la duración de la película en minutos: ");
                    int duracion = scanner.nextInt();
                    peliculaService.crearPelicula(titulo, genero, anio, duracion);
                    System.out.println("Película cargada correctamente.");
                    break;
                case 2:
                    peliculaService.listarPeliculasDisponibles();
                    break;
                case 3:
                    System.out.print("Ingrese el título de la película a alquilar: ");
                    String tituloAlquiler = scanner.next();
                    Pelicula peliculaAlquiler = peliculaService.buscarPeliculaPorTitulo(tituloAlquiler);
                    if (peliculaAlquiler == null) {
                        System.out.println("No se encontró la película.");
                        break;
                    }
                    System.out.print("Ingrese la fecha de inicio del alquiler (dd/mm/yyyy): ");
                    String fechaInicioStr = scanner.next();
                    System.out.print("Ingrese la fecha de fin del alquiler (dd/mm/yyyy): ");
                    String fechaFinStr = scanner.next();
                    // Aquí deberías parsear las fechas ingresadas por el usuario y crear el alquiler
                    // utilizando los métodos correspondientes del servicio de alquiler
                    // Ejemplo: alquilerService.crearAlquiler(peliculaAlquiler, fechaInicio, fechaFin, precio);
                    break;
                case 4:
                    alquilerService.listarAlquileres();
                    break;
                case 5:
                    System.out.print("Ingrese el título de la película a buscar: ");
                    String tituloBusqueda = scanner.next();
                    Pelicula peliculaEncontrada = peliculaService.buscarPeliculaPorTitulo(tituloBusqueda);
                    if (peliculaEncontrada == null) {
                        System.out.println("No se encontró la película.");
                    } else {
                        System.out.println("Película encontrada:");
                        System.out.println("Título: " + peliculaEncontrada.getTitulo());
                        System.out.println("Género: " + peliculaEncontrada.getGenero());
                        System.out.println("Año: " + peliculaEncontrada.getAnio());
                        System.out.println("Duración: " + peliculaEncontrada.getDuracion() + " minutos");
                    }
                    break;
                case 6:
                    System.out.print("Ingrese el género de la película a buscar: ");
                    String generoBusqueda = scanner.next();
                    Pelicula peliculaGenero = peliculaService.buscarPeliculaPorGenero(generoBusqueda);
                    if (peliculaGenero == null) {
                        System.out.println("No se encontró ninguna película con ese género.");
                    } else {
                        System.out.println("Película encontrada:");
                        System.out.println("Título: " + peliculaGenero.getTitulo());
                        System.out.println("Género: " + peliculaGenero.getGenero());
                        System.out.println("Año: " + peliculaGenero.getAnio());
                        System.out.println("Duración: " + peliculaGenero.getDuracion() + " minutos");
                    }
                    break;
                case 7:
                    System.out.print("Ingrese la fecha a buscar (dd/mm/yyyy): ");
                    String fechaBusquedaStr = scanner.next();
                    // Aquí deberías parsear la fecha ingresada por el usuario y buscar el alquiler
                    // utilizando el método correspondiente del servicio de alquiler
                    // Ejemplo: Alquiler alquilerEncontrado = alquilerService.buscarAlquilerPorFecha(fechaBusqueda);
                    break;
                case 8:
                    double ingresoTotal = alquilerService.calcularIngresoTotal();
                    System.out.println("El ingreso total del servicio es: $" + ingresoTotal);
                    break;
                case 9:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
            System.out.println();
        } while (opcion != 9);

        scanner.close();
    }
    
}
