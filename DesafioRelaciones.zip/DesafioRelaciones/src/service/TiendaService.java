package service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import entidades.Producto;
import entidades.Tienda;

public class TiendaService {

	private List<Tienda> listaTienda;
	private Scanner sc;
	
	public TiendaService() {
		this.listaTienda = new ArrayList<Tienda>();
		this.sc = new Scanner(System.in);
	}

	public List<Tienda> getListaTienda() {
		return listaTienda;
	}

	public void setListaTienda(List<Tienda> listaTienda) {
		this.listaTienda = listaTienda;
	}

	public Scanner getSc() {
		return sc;
	}

	public void setSc(Scanner sc) {
		this.sc = sc;
	}

	
	public Tienda crearTienda() {
		Tienda tienda = new Tienda();
		System.out.println("Ingrese el representante de la tienda");
		tienda.setRepresentante(sc.next());
		System.out.println("Ingrese la direcci�n de la tienda");
		tienda.setDireccion(sc.next());
		listaTienda.add(tienda);		
		return tienda;
	}
	
	public void mostrarTiendas() {
		for (Tienda tiendas : listaTienda) {
			System.out.println(tiendas);
		}
	}
	
	public void modificarTienda() {
		mostrarTiendas();
		System.out.println("Ingrese el ID de la tienda que desea modificar");
		int idModifica = sc.nextInt();
		boolean valida = false;
		for (Tienda tiendas : listaTienda) {
			if (tiendas.getId() == idModifica) {
				System.out.println(tiendas.getListaProductos());
				System.out.println("Ingrese la nueva direcci�n");
				tiendas.setDireccion(sc.next());
				System.out.println("Ingrese el nuevo representante");
				tiendas.setRepresentante(sc.next());
				valida = true;
			} 
		}
		if (valida) {
			System.out.println("La tienda ha sido modificada exitosamente!");
		}else {
			System.out.println("No se ha encontrado una tienda con ese ID");
		}
	}
	
	public void eliminarTienda() {
		mostrarTiendas();
		System.out.println("Ingrese el ID de la tienda que desea modificar");
		int idModifica = sc.nextInt();
		boolean valida = false;
		Iterator<Tienda> iterator = listaTienda.iterator();
        while (iterator.hasNext()) {
            Tienda tienda = iterator.next();
            if (tienda.getId() == idModifica) {
            	iterator.remove();
            	valida = true;
            }
        }
        if (valida) {
			System.out.println("La tienda ha sido eliminada exitosamente!");
		}else {
			System.out.println("No se ha encontrado una tienda con ese ID");
		}
        mostrarTiendas();
	}
	
	public void agregarProductos(Producto p, int cantidad) {
		mostrarTiendas();
		p.setStock(cantidad);
		System.out.println("Ingrese el id de la tienda a la que desea agregar el producto");
		int idModifica = sc.nextInt();
		boolean valida = false;
		for (Tienda tiendas : listaTienda) {
			if (tiendas.getId() == idModifica) {
				tiendas.getListaProductos().add(p);
				valida = true;
			} 
		}
		if (valida) {
			System.out.println("El producto ha sido agregado exitosamente!");
		}else {
			System.out.println("No se ha encontrado un producto con ese ID");
		}
	}
	
	public void venderProducto() {
		mostrarTiendas();
		System.out.println("Ingrese el id de la tienda en la que desea comprar");
		int idTienda = sc.nextInt();
		boolean valida = false;
		for (Tienda tiendas : listaTienda) {
			if (tiendas.getId() == idTienda) {
				tiendas.getListaProductos();
				System.out.println("Ingrese el id del producto que desea comprar");
				int idProducto = sc.nextInt();
				//boolean valida = false;
				for (Producto producto : tiendas.getListaProductos()) {
					if (producto.getId() == idProducto) {
						if (producto.getStock()>0) {
						System.out.println("Quedan "+producto.getStock()+"unidades, y el precio es: $"+producto.getPrecio());
						System.out.println("Cuantas unidades desea comprar?");
						int cantComprada = sc.nextInt();
							if (cantComprada <= producto.getStock()) {
							producto.setStock(producto.getStock()-cantComprada);
							valida = true;
							}else {
								System.out.println("No hay stock suficiente");
							}
						}else {
							System.out.println("No hay stock suficiente");
						}
					} 
				}
				if (valida) {
					System.out.println("Gracias por su compra!");
				}else {
					System.out.println("No se pudo vender el producto");
				}
			} 
		}	
	}
	
	public void eliminarProductos() {
		mostrarTiendas();
		System.out.println("Ingrese el id de la tienda en la que desea comprar");
		int idTienda = sc.nextInt();
		boolean valida = false;
		
		for (Tienda tiendas : listaTienda) {
			if (tiendas.getId() == idTienda) {
				tiendas.getListaProductos();
				System.out.println("Ingrese el id del producto que desea eliminar");
				int idProducto = sc.nextInt();
				
				Iterator<Producto> iterator = tiendas.getListaProductos().iterator();
		        while (iterator.hasNext()) {
		            Producto p = iterator.next();
		            if (p.getId() == idProducto) {
		            	iterator.remove();
		            	valida = true;
		            }
		        }
		        if (valida) {
					System.out.println("El producto ha sido eliminado exitosamente!");
				}else {
					System.out.println("No se ha encontrado un producto con ese ID");
				}
				if (valida) {
					System.out.println("Gracias por su compra!");
				}else {
					System.out.println("No se pudo vender el producto");
				}
			} 
		}	
	}
	
	
	public void stockProductos() {
		mostrarTiendas();
		System.out.println("Ingrese el id de la tienda a la que desea agregar el producto");
		int idModifica = sc.nextInt();
		boolean valida = false;
		for (Tienda tiendas : listaTienda) {
			if (tiendas.getId() == idModifica) {
				for (int i = 0; i < tiendas.getListaProductos().size(); i++) {
					System.out.println("ID Producto: "+tiendas.getListaProductos().get(i).getId()+" | Stock: "+tiendas.getListaProductos().get(i).getStock());
				}
			} 
		}
	}
	
}
