package service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import entidades.Producto;
import entidades.Tienda;

public class ProductoService {

	private List<Producto> listaProducto;
	
	public ProductoService() {
		super();
		this.listaProducto = new ArrayList<>();
	}

	public List<Producto> getListaProducto() {
		return listaProducto;
	}

	public void setListaProducto(List<Producto> listaProducto) {
		this.listaProducto = listaProducto;
	}
	
	public Producto crearProducto() {
		Producto p = new Producto();
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese el nombre del producto");
		p.setNombre(sc.next());
		System.out.println("Ingrese el precio del producto");
		p.setPrecio(sc.nextDouble());
		listaProducto.add(p);
		return p;
	}
	
	public void mostrarProductos() {
		for (Producto producto : listaProducto) {
			System.out.println(producto);
		}
	}
	
	public void modificarProducto() {
		mostrarProductos();
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese el ID del producto que desea modificar");
		int idModifica = sc.nextInt();
		boolean valida = false;
		for (Producto p : listaProducto) {
			if (p.getId() == idModifica) {
				System.out.println("Ingrese el nuevo nombre");
				p.setNombre(sc.next());
				System.out.println("Ingrese el nuevo precio");
				p.setPrecio(sc.nextDouble());
				valida = true;
			} 
		}
		if (valida) {
			System.out.println("El producto ha sido modificado exitosamente!");
		}else {
			System.out.println("No se ha encontrado un producto con ese ID");
		}
	}
	
	public void eliminarProducto() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Ingrese el ID del producto que desea modificar");
		int idModifica = sc.nextInt();
		boolean valida = false;
		Iterator<Producto> iterator = listaProducto.iterator();
        while (iterator.hasNext()) {
            Producto p = iterator.next();
            if (p.getId() == idModifica) {
            	iterator.remove();
            	valida = true;
            }
        }
        if (valida) {
			System.out.println("La tienda ha sido eliminada exitosamente!");
		}else {
			System.out.println("No se ha encontrado una tienda con ese ID");
		}
        mostrarProductos();
	}
	
}
