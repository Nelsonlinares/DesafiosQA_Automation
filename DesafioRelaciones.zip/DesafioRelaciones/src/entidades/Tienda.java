package entidades;

import java.util.ArrayList;
import java.util.List;

public class Tienda {
	
	private static int nextID = 1;
	private int id;
	private List<Producto> listaProductos;
	private String direccion;
	private String representante;
	
	public Tienda() {
		this.id = nextID;
		nextID++;
		this.listaProductos = new ArrayList<Producto>();
	}

	public Tienda(int id, List<Producto> listaProductos, String direccion, String representante) {
		this.id = id;
		this.listaProductos = listaProductos;
		this.direccion = direccion;
		this.representante = representante;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Producto> getListaProductos() {
		return listaProductos;
	}

	public void setListaProductos(List<Producto> listaProductos) {
		this.listaProductos = listaProductos;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getRepresentante() {
		return representante;
	}

	public void setRepresentante(String representante) {
		this.representante = representante;
	}
	
	@Override
	public String toString() {
		return "Tienda [id=" + id + ", listaProductos=" + listaProductos + ", direccion=" + direccion
				+ ", representante=" + representante + "]";
	}
	
}
