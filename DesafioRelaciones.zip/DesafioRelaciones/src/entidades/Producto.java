package entidades;

public class Producto {
	
	private static int nextID = 1;
	private int id;
	private String nombre;
	private double precio;
	private int stock;
	
	public Producto() {
		this.id = nextID;
		nextID++;
		this.stock = 0;
	}

	public Producto(String nombre, double precio) {
		this.id = nextID;
		nextID++;
		this.nombre = nombre;
		this.precio = precio;
		this.stock = 0;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}
	
	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}
	
	@Override
	public String toString() {
		return "Producto [id=" + id + ", nombre=" + nombre + ", precio=" + precio + "]";
	}
}
