package main;

import java.util.Scanner;

import entidades.Producto;
import entidades.Tienda;
import service.ProductoService;
import service.TiendaService;

public class Main {

	public static void main(String[] args) {
		TiendaService tS = new TiendaService();
		ProductoService pS = new ProductoService();
		Scanner sc = new Scanner(System.in);
		//Creamos tres tiendas
		Tienda tiendaUno = tS.crearTienda();
		Tienda tiendaDos = tS.crearTienda();
		Tienda tiendaTres = tS.crearTienda();
		//Creamos 15 productos
		Producto pUno = pS.crearProducto();
		Producto pDos = pS.crearProducto();
		Producto pTres = pS.crearProducto();
		Producto pCuatro = pS.crearProducto();
		Producto pCinco = pS.crearProducto();
		/*Producto pSeis = new Producto();
		Producto pSiete = new Producto();
		Producto pOcho = new Producto();
		Producto pNueve = new Producto();
		Producto pDiez = new Producto();
		Producto pOnce = new Producto();
		Producto pDoce = new Producto();
		Producto pTrece = new Producto();
		Producto pCatorce = new Producto();
		Producto pQuince = new Producto();*/
		tS.mostrarTiendas();
		System.out.println("Ingrese la cantidad del producto a agregar");
		int cant = sc.nextInt();
		tS.agregarProductos(pCinco, cant);
		tS.agregarProductos(pUno, cant);
		tS.agregarProductos(pCinco, cant);
		tS.venderProducto();
		tS.stockProductos();
	}

}
